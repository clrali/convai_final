#!/bin/bash
# Usage: sbatch --export=ALL,STAGE=baselines_dev slurm/stage.sbatch
# Stages: data pilot baselines_dev wsp adapt freeze test side analyze
#SBATCH -J wsp-mol
#SBATCH -N 1
#SBATCH --ntasks-per-node=4
#SBATCH --gres=gpu:1                 # 16 GB GPU is enough (e.g. add -C V100-16GB if needed)
#SBATCH --mem=32G
#SBATCH -t 08:00:00
#SBATCH -o logs/%x-%j.out

cd "$SLURM_SUBMIT_DIR"
module load anaconda3 2>/dev/null || true
source activate wspmol 2>/dev/null || conda activate wspmol 2>/dev/null || true
export HF_HOME="$SLURM_SUBMIT_DIR/.hf_cache"
nvidia-smi
STAGE=${STAGE:-all} bash scripts/run_all.sh "${MODEL:-allenai/OLMo-2-0425-1B-Instruct}"
